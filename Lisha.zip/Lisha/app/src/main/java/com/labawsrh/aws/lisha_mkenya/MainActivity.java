package com.labawsrh.aws.lisha_mkenya;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2, e3, e4, e5, e6;
    DatePickerDialog picker;
    private TextView placeName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        e1 = (EditText) findViewById(R.id.fname);
        e2 = (EditText) findViewById(R.id.lname);
        e3 = (EditText) findViewById(R.id.email);
        e4 = (EditText) findViewById(R.id.phone);
        e5 = (EditText) findViewById(R.id.donation);
        e6 = (EditText) findViewById(R.id.date);
        e6.setInputType(InputType.TYPE_NULL);
        e6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(MainActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                e6.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });
    }

    public void OnDonate(View view) {
        String first_name = e1.getText().toString();
        String last_name = e2.getText().toString();
        String email = e3.getText().toString();
        String phone = e4.getText().toString();
        String donation = e5.getText().toString();
        String date = e6.getText().toString();
        String type = "Donate";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type, first_name, last_name, email, phone, donation, date);
    }
}